"use client";

import React, { useEffect, useState } from "react";

export default function Header() {
  const [onlineCount, setOnlineCount] = useState(1050);

  useEffect(() => {
    // Start with a random base between 950 and 1150
    setOnlineCount(Math.floor(Math.random() * 200) + 950);

    const interval = setInterval(() => {
      setOnlineCount((prev) => {
        // Randomly decide whether to increase or decrease
        const isIncrease = Math.random() > 0.4; // 60% chance to increase, 40% to decrease
        // Fluctuate by a random amount between 1 and 7
        const fluctuate = Math.floor(Math.random() * 7) + 1;
        
        let newCount = isIncrease ? prev + fluctuate : prev - fluctuate;
        
        // Keep it realistic, don't drop below 800
        if (newCount < 800) newCount = 800 + fluctuate;

        // NOTE: In production with a real WebSocket, you would replace this simulation 
        // with the actual live user count if the real count is > 1000.
        // e.g., if (realLiveCount > 1000) return realLiveCount;

        return newCount;
      });
    }, 4500); // Update every 4.5 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <header className="absolute top-2.5 sm:top-4 left-0 right-0 z-30 px-2.5 xs:px-3 sm:px-6 max-w-7xl mx-auto w-full">
      <div className="flex items-center justify-between gap-1.5 xs:gap-2 sm:gap-3 w-full">
        {/* 1. Online Counter Badge */}
        <div className="header-pill flex-1 sm:flex-initial sm:min-w-[105px] px-2 xs:px-3 text-emerald-400 gap-1.5 shrink-0 select-none">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0 shadow-[0_0_8px_rgba(52,211,153,0.8)]"></span>
          <span className="text-white/95 font-mono font-bold tracking-tight">{onlineCount}</span>
          <span className="text-white/60 text-[10px] font-normal">online</span>
        </div>

        {/* 2. Theme Selector */}
        <div className="theme-select-wrap flex-1 sm:flex-initial sm:w-44 shrink-0">
          <select aria-label="Choose theme" className="theme-select w-full" defaultValue="">
            <option value="" disabled hidden>
              Change Theme
            </option>
            <option value="/">🕌 Sukoon</option>
            <option value="/night">🌙 Night Mode</option>
          </select>
        </div>

        {/* 3. Right side: About, FAQ, Support */}
        <nav aria-label="Primary" className="flex items-center gap-1.5 xs:gap-2 flex-1 sm:flex-initial justify-end shrink-0">
          <a href="#about" className="hidden sm:inline-flex header-pill px-3.5">
            About
          </a>
          <a href="#faq" className="hidden sm:inline-flex header-pill px-3.5">
            FAQ
          </a>

          <button
            type="button"
            aria-label="Open support modal"
            className="header-pill w-full sm:w-auto px-2 xs:px-3 sm:px-3.5 gap-1.5 hover:border-amber-400/50 hover:text-amber-200"
            onClick={() => window.dispatchEvent(new CustomEvent("open-support-modal"))}
          >
            <span className="text-xs text-red-400 animate-pulse shrink-0" aria-hidden="true">
              ❤️
            </span>
            <span className="font-semibold text-white/90 text-[11px] xs:text-xs">Support</span>
          </button>
        </nav>
      </div>
    </header>
  );
}
