"use client";

import React, { useState, useRef, useEffect } from 'react';
import YouTubePlayer from '@/components/YouTubePlayer';
import AtmosphereCanvas from '@/components/AtmosphereCanvas';
import Header from '@/components/Header';
import VintagePlayer from '@/components/VintagePlayer';
import Modals from '@/components/Modals';
import { TRACK_MAP } from '@/data/trackMap';

function formatTime(s: number) {
  if (!s || isNaN(s)) return '0:00';
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec < 10 ? '0' : ''}${sec}`;
}

export default function Home() {
  const [isReady, setIsReady] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentVideoId, setCurrentVideoId] = useState<string | null>(null);
  const [videoTitle, setVideoTitle] = useState<string>("");
  const [progressPct, setProgressPct] = useState(0);
  const [currentTimeStr, setCurrentTimeStr] = useState("0:00");
  const [totalTimeStr, setTotalTimeStr] = useState("0:00");

  const playerRef = useRef<any>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      if (playerRef.current && playerRef.current.getCurrentTime) {
        const cur = playerRef.current.getCurrentTime() || 0;
        const dur = playerRef.current.getDuration() || 0;
        setCurrentTimeStr(formatTime(cur));
        setTotalTimeStr(formatTime(dur));
        const pct = dur > 0 ? (cur / dur) * 100 : 0;
        setProgressPct(pct);

        // Also constantly update video title in case it changes
        const data = playerRef.current.getVideoData();
        if (data && data.title) setVideoTitle(data.title);
      }
    }, 500);
    return () => clearInterval(interval);
  }, []);

  const handlePlayerReady = (player: any) => {
    playerRef.current = player;
    setIsReady(true);
    const data = player.getVideoData();
    if (data && data.title) setVideoTitle(data.title);
  };

  const handleStateChange = (event: any) => {
    // 1 = playing, 2 = paused, 0 = ended
    if (event.data === 1) {
      setIsPlaying(true);
    } else if (event.data === 2 || event.data === 0) {
      setIsPlaying(false);
    }

    if (playerRef.current) {
      const data = playerRef.current.getVideoData();
      if (data && data.video_id && data.video_id !== currentVideoId) {
        setCurrentVideoId(data.video_id);
      }
      if (data && data.title) {
        setVideoTitle(data.title);
      }
    }
  };

  const handleError = (event: any) => {
    console.error("YouTube Player Error:", event.data);
    if (playerRef.current) {
      playerRef.current.nextVideo();
    }
  };

  const handlePlayPause = () => {
    if (!playerRef.current) return;
    
    if (isPlaying) {
      playerRef.current.pauseVideo();
    } else {
      playerRef.current.unMute();
      playerRef.current.playVideo();
    }
  };

  const handleNext = () => {
    if (playerRef.current) {
      playerRef.current.nextVideo();
    }
  };

  const handlePrev = () => {
    if (playerRef.current) {
      playerRef.current.previousVideo();
    }
  };

  const handleSeek = (pct: number) => {
    if (playerRef.current && playerRef.current.getDuration) {
      const dur = playerRef.current.getDuration();
      playerRef.current.seekTo(pct * dur, true);
    }
  };

  const handleVolumeChange = (level: number) => {
    if (playerRef.current) {
      if (level === 0) {
        playerRef.current.mute();
      } else {
        playerRef.current.unMute();
        playerRef.current.setVolume(level);
      }
    }
  };

  const currentMeta = currentVideoId ? TRACK_MAP[currentVideoId] : null;

  return (
    <section className="relative w-full h-[100svh] overflow-hidden select-none bg-[#120806]">
      <AtmosphereCanvas />
      
      <Header />

      <main className="absolute inset-0 z-10 flex flex-col items-center justify-between pt-14 pb-2 xs:pb-3 sm:pt-20 sm:pb-6 px-3 sm:px-6 pointer-events-none">
        
        {/* Title */}
        <div className="pointer-events-auto drop-shadow-[0_12px_35px_rgba(0,0,0,0.95)] text-center mt-6 xs:mt-8 sm:mt-0 sm:mb-1">
          <h1 className="font-hindi text-6xl xs:text-7xl sm:text-8xl md:text-9xl lg:text-[9.5rem] font-extrabold tracking-wide text-white leading-[0.88] mt-[10vh]">
            سُكُون
          </h1>
          <p className="mt-4 text-white/70 text-sm tracking-[0.2em] uppercase">Sukoon</p>

          <button
            type="button"
            className="tweak-pill group border-amber-500/40 text-amber-300 hover:text-amber-100 hover:border-amber-400 cursor-pointer mt-6 mx-auto"
            onClick={() => window.dispatchEvent(new CustomEvent("open-chat-modal"))}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse shrink-0" aria-hidden="true"></span>
            <span className="font-medium tracking-wide">💬 Live Chat</span>
          </button>
        </div>

        <div className="w-full max-w-md xs:max-w-lg sm:max-w-2xl flex flex-col items-center gap-2 sm:gap-3 mt-auto mb-1 sm:my-auto">
          {/* Share Button Row */}
          <div className="order-0 pointer-events-auto flex items-center justify-center gap-1.5 xs:gap-2 flex-nowrap max-w-full overflow-x-auto no-scrollbar py-1 px-1">
            <button
              type="button"
              className="share-toggle-pill group shrink-0"
              onClick={() => {
                const message = encodeURIComponent("Find peace with Sukoon - ambient Quran radio ✨\n\nListen now 👉🏻 https://sukoon.example.com");
                window.open(`https://api.whatsapp.com/send?text=${message}`, "_blank");
              }}
            >
              <svg className="w-3.5 h-3.5 fill-current text-[#25D366] shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
              </svg>
              <span className="font-medium tracking-wide">Share</span>
            </button>
          </div>

          <VintagePlayer
            isPlaying={isPlaying}
            progress={progressPct}
            currentTime={currentTimeStr}
            totalTime={totalTimeStr}
            trackName={currentMeta?.surahNameArabic || videoTitle || "Loading Surah..."}
            channelName={"Sukoon Radio"}
            coverUrl={`https://img.youtube.com/vi/${currentVideoId}/hqdefault.jpg`}
            onPlayPause={handlePlayPause}
            onNext={handleNext}
            onPrev={handlePrev}
            onSeek={handleSeek}
            onVolumeChange={handleVolumeChange}
          />

          <footer className="order-3 sm:order-3 pointer-events-auto text-[8.5px] sm:text-xs text-white/50 tracking-widest font-mono mt-0 sm:mt-1">
            contact: salam@sukoon.example.com
          </footer>
        </div>
      </main>

      <Modals />

      <YouTubePlayer 
        onReady={handlePlayerReady} 
        onStateChange={handleStateChange}
        onError={handleError}
      />
    </section>
  );
}
