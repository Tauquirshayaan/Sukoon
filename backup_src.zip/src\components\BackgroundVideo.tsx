"use client";

import React, { useEffect, useState } from 'react';

interface BackgroundVideoProps {
  mood: string;
}

// Fallback colors until videos are provided
const MOOD_COLORS: Record<string, string> = {
  dawn: '#3b4252',
  dunes: '#d08770',
  water: '#5e81ac',
  default: '#2e3440'
};

const ALL_MOODS = ['dawn', 'dunes', 'water', 'default'];

export default function BackgroundVideo({ mood }: BackgroundVideoProps) {
  const activeMood = mood || 'default';

  return (
    <div className="background-container">
      {ALL_MOODS.map((m) => {
        const isActive = m === activeMood;
        return (
          <div
            key={m}
            className={`background-layer ${isActive ? 'active' : ''}`}
            style={{ backgroundColor: MOOD_COLORS[m] || MOOD_COLORS.default }}
          >
            {/* 
              TODO: When videos are provided, uncomment the video tag and ensure they are placed in public/videos/.
              For now, the background color will crossfade instead.
            */}
            {/*
            <video
              src={`/videos/${m}.mp4`}
              loop
              autoPlay
              muted
              playsInline
              className="background-video"
            />
            */}
          </div>
        );
      })}
    </div>
  );
}
