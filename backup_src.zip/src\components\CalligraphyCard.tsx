"use client";

import React from 'react';
import { TrackMeta } from '@/data/trackMap';

interface CalligraphyCardProps {
  meta: TrackMeta | null;
}

export default function CalligraphyCard({ meta }: CalligraphyCardProps) {
  if (!meta) {
    return (
      <div className="calligraphy-card empty">
        {/* Placeholder state while loading */}
      </div>
    );
  }

  return (
    <div className="calligraphy-card fade-in" key={meta.videoId}>
      <h1 className="surah-name" dir="rtl">{meta.surahNameArabic}</h1>
      <p className="opening-ayah" dir="rtl">{meta.openingAyahArabic}</p>
      <span className="reference">{meta.reference}</span>
    </div>
  );
}
